function playSound(note) {
  alert("你按下了 " + note + " 音！(此处可加入音频播放)");
}